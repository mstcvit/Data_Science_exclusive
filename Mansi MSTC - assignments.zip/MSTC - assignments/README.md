# MSTC_Data-Science_tasks

Project Tasks given by STC - VIT (Tech Club of Vellore Institute of Technology)
